FindTranslations is a simple Android application made by yours truly (Paul Kang) for the Duolingo Android Developer job application. I did spend a good amount of time on this, hope you are pleased with the result :).

Application Icon made by Smashicons (https://www.flaticon.com/authors/smashicons) from www.flaticon.com (https://www.flaticon.com/)

